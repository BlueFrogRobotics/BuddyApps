﻿using BlueQuark;

using UnityEngine;
using UnityEngine.UI;

using System;
using System.Collections;
using System.Collections.Generic;

namespace BuddyApp.{APP_NAME}
{
    /* A basic monobehaviour as "AI" behaviour for your app */
    public class {APP_NAME}Behaviour : MonoBehaviour
    {
        /*
         * Data of the application. Save on disc when app is quitted
         */
        private {APP_NAME}Data mAppData;

        void Start()
        {
			/*
			* You can setup your App activity here.
			*/
			{APP_NAME}Activity.Init(null);
			
			/*
			* Init your app data
			*/
            mAppData = {APP_NAME}Data.Instance;
        }
    }
}