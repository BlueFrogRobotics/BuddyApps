﻿using BlueQuark;

namespace BuddyApp.{APP_NAME}
{
    /* Data are stored in xml file for persistent data purpose */
    public class {APP_NAME}Data : AAppData
    {
        /*
         * Data getters / setters
         */
        public int MyValue { get; set; }

        /*
         * Data singleton access
         */
        public static {APP_NAME}Data Instance
        {
            get
            {
                if (sInstance == null)
                    sInstance = GetInstance<{APP_NAME}Data>();
                return sInstance as {APP_NAME}Data;
            }
        }
    }
}
