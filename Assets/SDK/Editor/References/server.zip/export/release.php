<?php
	const APPS_PATH = "../applications/Apps/";
	const RELEASE_FILE = "release";

	const SUCCESS_STATUS = "SUCCESS";

	const BAD_REQUEST_FAILURE = "Bad request.";
	const BAD_PARAMS_FAILURE = "Bad parameters.";

	function ReleaseAppVersion($id, $version)
	{
		$applicationPath = APPS_PATH . $id . "/";

		file_put_contents($applicationPath . RELEASE_FILE, $version);

		return SUCCESS_STATUS;
	}

	function RemoveReleaseApp($id)
	{
		$applicationPath = APPS_PATH . $id . "/";
		if (file_exists($applicationPath . RELEASE_FILE))
			unlink($applicationPath . RELEASE_FILE);

		return SUCCESS_STATUS;
	}

	function ReleaseApp()
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;
		
		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["id"]) || !$_POST["id"])
			return BAD_PARAMS_FAILURE;


		$version = (isset($_POST["version"])) ? $_POST["version"] : null;
		return $version ? ReleaseAppVersion($_POST["id"], $version) : RemoveReleaseApp($_POST["id"]);
	}

	echo ReleaseApp();
?>
