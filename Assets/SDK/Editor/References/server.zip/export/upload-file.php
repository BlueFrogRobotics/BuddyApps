<?php
	const MAIN_PATH = "../applications";
	const META_FILE = "meta.xml";

	const SUCCESS_STATUS = "SUCCESS";

	const BAD_REQUEST_FAILURE = "Bad request.";
	const BAD_PARAMS_FAILURE = "Bad parameters.";
	const NOT_FOUND_FAILURE = "File not upload correctly.";
	const CANT_MOVE_FAILURE = "File can't be move.";

	function RetrieveFile($path)
	{
		if (!isset($_FILES) || !isset($_FILES["file"]) || !$_FILES["file"]["name"])
			return NOT_FOUND_FAILURE;

		$filename = $_FILES["file"]["name"];
		$source = $_FILES["file"]["tmp_name"];

		$path = MAIN_PATH . "/" . $path;

		if (file_exists($path))
			unlink($path);

		if (!move_uploaded_file($source, $path))
			return CANT_MOVE_FAILURE;

		return SUCCESS_STATUS;
	}

	function UploadFile()
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;

		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["path"]) || !$_POST["path"])
			return BAD_PARAMS_FAILURE;

		return RetrieveFile($_POST["path"]);
	}

	echo UploadFile();
?>
