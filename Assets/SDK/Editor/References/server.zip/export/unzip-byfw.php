<?php

	include 'utilities.php';

	function RetrieveAndUnzipFile($file, $destination)
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;

		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["version"]) || !$_POST["version"])
			return BAD_PARAMS_FAILURE;

		$deletedFiles = isset($_POST["deleted"]) ? $_POST["deleted"] : [];
		$deletedFiles = $deletedFiles == null ? [] : $deletedFiles;

		$file = BYFW_PATH . ZIPPED_BYFW_FILE;
		$destination = BYFW_PATH . $_POST["version"] . "/";

		if (!file_exists($file))
			return NOT_FOUND_FAILURE;

		$zip = new ZipArchive;
		if (($res = $zip->open($file)) !== true)
			return UNZIP_FAILURE;

		try {
			
			$zip->extractTo($destination);
			$zip->close();

			unlink($file);
		} catch (Exception $e) {
			return UNZIP_FAILURE;
		}

		foreach ($deletedFiles as $deletedFile)
			unlink($destination . $deletedFile);

		return SUCCESS_STATUS;
	}

	echo RetrieveAndUnzipFile();
?>
