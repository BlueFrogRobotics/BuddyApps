<?php

	include 'utilities.php';

	function HasVersions($applicationPath)
	{
		$directories = scandir($applicationPath);
		foreach ($directories as $version)
		{
			if (!is_dir($applicationPath . $version))
				continue;

			if ($version == ".." || $version == ".")
				continue;

			return true;
		}

		return false;
	}

	function DeleteRemoteVersion($id, $version)
	{
		$applicationPath = APPS_PATH . $id . "/";

		$tags = GetApplicationTags($id);
		$tags = array_filter($tags, function($value) use ($version) {
			return $version != $value;
		});
		
		SyncApplicationTags($id, $tags);

		if (!DeleteRecursiveDirectory($applicationPath . $version))
			return DELETE_DIRECTORY_FAILURE;

		if (HasVersions($applicationPath))
			return SUCCESS_STATUS;

		if (!DeleteRecursiveDirectory($applicationPath))
			return DELETE_DIRECTORY_FAILURE;

		return SUCCESS_STATUS;
	}

	function DeleteRemoteApp($id)
	{
		$applicationPath = APPS_PATH . $id . "/";

		if (!DeleteRecursiveDirectory($applicationPath))
			return DELETE_DIRECTORY_FAILURE;

		return SUCCESS_STATUS;
	}

	function DeleteApp()
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;
		
		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["id"]) || !$_POST["id"])
			return BAD_PARAMS_FAILURE;

		$version = (isset($_POST["version"])) ? $_POST["version"] : null;
		return $version ? DeleteRemoteVersion($_POST["id"], $version) : DeleteRemoteApp($_POST["id"]);
	}

	echo DeleteApp();
?>
