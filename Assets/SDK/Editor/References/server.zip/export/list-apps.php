<?php

	include 'utilities.php';

	function ListAvailableApps()
	{
		$apps = [];

		try {
			$files = scandir(APPS_PATH);
		} catch (Exception $e) {
			return json_encode(["status" => false]);
		}

		foreach ($files as $file)
		{
			if (!is_dir(APPS_PATH . $file))
				continue;

			if ($file == ".." || $file == ".")
				continue;
			
			$versions = [];
			$directories = scandir(APPS_PATH . $file . "/");
			foreach ($directories as $version)
			{
				if (!is_dir(APPS_PATH . $file . "/" . $version))
					continue;

				if ($version == ".." || $version == ".")
					continue;

				$versions[] = $version;
			}

			if (empty($versions))
				continue;

			sort($versions);

			$tags = GetApplicationTags($file);

			$apps[] = ["id" => $file, "develop" => $tags["develop"], "release" => $tags["release"], "versions" => $versions];
		}

		$result = ["status" => true, "apps" => $apps];
		return json_encode($result);
	}

	echo ListAvailableApps();
?>