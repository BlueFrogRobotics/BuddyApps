<?php
	const APPS_PATH = "../applications/Apps/";
	const RELEASE_FILE = "release";

	const SUCCESS_STATUS = "SUCCESS";

	const BAD_REQUEST_FAILURE = "Bad request.";
	const BAD_PARAMS_FAILURE = "Bad parameters.";
	const DELETE_DIRECTORY_FAILURE = "Failure while deleting directory.";

	function DeleteRecursiveDirectory($directory) {
	    if (!file_exists($directory))
	        return true;

	    if (!is_dir($directory))
	        return unlink($directory);

	    foreach (scandir($directory) as $item) {
	        if ($item == '.' || $item == '..')
	            continue;

	        if (!DeleteRecursiveDirectory($directory . '/' . $item))
	            return false;
	    }

	    return rmdir($directory);
	}

	function HasVersions($applicationPath)
	{
		$directories = scandir($applicationPath);
		foreach ($directories as $version)
		{
			if (!is_dir($applicationPath . $version))
				continue;

			if ($version == ".." || $version == ".")
				continue;

			return true;
		}

		return false;
	}

	function DeleteRemoteVersion($id, $version)
	{
		$applicationPath = APPS_PATH . $id . "/";

		if (file_exists($applicationPath . RELEASE_FILE) && $version == file_get_contents($applicationPath . RELEASE_FILE))
			unlink($applicationPath . RELEASE_FILE);

		if (!DeleteRecursiveDirectory($applicationPath . $version))
			return DELETE_DIRECTORY_FAILURE;

		if (HasVersions($applicationPath))
			return SUCCESS_STATUS;

		if (!DeleteRecursiveDirectory($applicationPath))
			return DELETE_DIRECTORY_FAILURE;

		return SUCCESS_STATUS;
	}

	function DeleteRemoteApp($id)
	{
		$applicationPath = APPS_PATH . $id . "/";

		if (!DeleteRecursiveDirectory($applicationPath))
			return DELETE_DIRECTORY_FAILURE;

		return SUCCESS_STATUS;
	}

	function DeleteApp()
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;
		
		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["id"]) || !$_POST["id"])
			return BAD_PARAMS_FAILURE;

		$version = (isset($_POST["version"])) ? $_POST["version"] : null;
		return $version ? DeleteRemoteVersion($_POST["id"], $version) : DeleteRemoteApp($_POST["id"]);
	}

	echo DeleteApp();
?>
