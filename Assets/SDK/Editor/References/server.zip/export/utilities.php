<?php

	const MAIN_PATH = "../applications/";
	const APPS_PATH = "../applications/Apps/";
	const BYFW_PATH = "../applications/BYFW/";
	const CORE_PATH = "../applications/Core/";

	const TAG_VERSIONS_FILE = "versions";
	const META_FILE = "meta.xml";
	const ZIPPED_BYFW_FILE = "byfw.zip";

	const SUCCESS_STATUS = "SUCCESS";
	const BAD_REQUEST_FAILURE = "Bad request.";
	const BAD_PARAMS_FAILURE = "Bad parameters.";
	const NOT_FOUND_FAILURE = "File not upload correctly.";
	const DELETE_DIRECTORY_FAILURE = "Failure while deleting directory.";
	const UNZIP_FAILURE = "Failure while unzipping file.";
	const CANT_MOVE_FAILURE = "File can't be move.";

	function GetApplicationTags($id)
	{
		$tags = ['release' => '', 'develop' => ''];
		$tagsPath = APPS_PATH . $id . "/" . TAG_VERSIONS_FILE;
				
		if (!file_exists($tagsPath))
			return $tags;

		$content = file_get_contents($tagsPath);
		$contentLines = explode("\n", $content);

		foreach ($contentLines as $line)
		{
			$splitted = explode('=', $line);
			if (count($splitted) != 2)
				continue;

			$tags[$splitted[0]] = $splitted[1];
		}

		return $tags;
	}

	function SyncApplicationTags($id, $newTags)
	{
		$tags = GetApplicationTags($id);
		$tags = array_merge($tags, $newTags);		

		$tagsPath = APPS_PATH . $id . "/" . TAG_VERSIONS_FILE;
		if (file_exists($tagsPath))
			unlink($tagsPath);

		$content = "";
		foreach ($tags as $key => $value) {
			if (!$value)
				continue;
			$content .= $key . "=" . $value . "\n";
		}

		file_put_contents($tagsPath, $content);
	}

	function DeleteRecursiveDirectory($directory) {
	    if (!file_exists($directory))
	        return true;

	    if (!is_dir($directory))
	        return unlink($directory);

	    foreach (scandir($directory) as $item) {
	        if ($item == '.' || $item == '..')
	            continue;

	        if (!DeleteRecursiveDirectory($directory . '/' . $item))
	            return false;
	    }

	    return rmdir($directory);
	}

?>