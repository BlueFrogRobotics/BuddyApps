<?php
	const EXPORT_APPS_PATH = "../applications/Apps/";
	const RELEASE_FILE = "release";

	const SUCCESS_STATUS = true;
	const ERROR_STATUS = false;

	function ListAvailableApps()
	{
		$apps = [];

		try {
			$files = scandir(EXPORT_APPS_PATH);
		} catch (Exception $e) {
			return json_encode(["status" => ERROR_STATUS]);
		}

		foreach ($files as $file)
		{
			if (!is_dir(EXPORT_APPS_PATH . $file))
				continue;

			if ($file == ".." || $file == ".")
				continue;
			
			$release = "";
			if (file_exists(EXPORT_APPS_PATH . $file . "/" . RELEASE_FILE))
				$release = file_get_contents(EXPORT_APPS_PATH . $file . "/" . RELEASE_FILE);

			$versions = [];
			$directories = scandir(EXPORT_APPS_PATH . $file . "/");
			foreach ($directories as $version)
			{
				if (!is_dir(EXPORT_APPS_PATH . $file . "/" . $version))
					continue;

				if ($version == ".." || $version == ".")
					continue;

				$versions[] = $version;
			}

			sort($versions);

			$apps[] = ["id" => $file, "release" => $release, "versions" => $versions];
		}

		$result = ["status" => SUCCESS_STATUS, "apps" => $apps];
		return json_encode($result);
	}

	echo ListAvailableApps();
?>