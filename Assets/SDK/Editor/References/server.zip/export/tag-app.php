<?php

	include 'utilities.php';

	function TagApp()
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;
		
		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["id"]) || !$_POST["id"])
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["release"]))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["develop"]))
			return BAD_PARAMS_FAILURE;

		SyncApplicationTags($_POST["id"], ["release" => $_POST["release"], "develop" => $_POST["develop"]]);

		return SUCCESS_STATUS;
	}

	echo TagApp();
?>
