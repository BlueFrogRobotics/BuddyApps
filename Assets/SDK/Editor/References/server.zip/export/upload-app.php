<?php
	const EXPORT_APPS_PATH = "../applications/Apps/";
	const RELEASE_FILE = "release";

	const SUCCESS_STATUS = "SUCCESS";

	const BAD_REQUEST_FAILURE = "Bad request.";
	const BAD_PARAMS_FAILURE = "Bad parameters.";
	const NOT_FOUND_FAILURE = "File not upload correctly.";
	const DELETE_DIRECTORY_FAILURE = "Failure while deleting directory.";
	const UNZIP_FAILURE = "Failure while unzipping file.";

	function DeleteRecursiveDirectory($directory) {
	    if (!file_exists($directory))
	        return true;

	    if (!is_dir($directory))
	        return unlink($directory);

	    foreach (scandir($directory) as $item) {
	        if ($item == '.' || $item == '..')
	            continue;

	        if (!DeleteRecursiveDirectory($directory . '/' . $item))
	            return false;
	    }

	    return rmdir($directory);
	}

	function OverrideAppVersion($applicationID, $oldVersion, $newVersion)
	{
		if (!DeleteRecursiveDirectory(EXPORT_APPS_PATH . "/" . $applicationID . "/" . $oldVersion))
			return DELETE_DIRECTORY_FAILURE;

		$releaseFilePath = EXPORT_APPS_PATH . "/" . $applicationID . "/" . RELEASE_FILE;

		if (!file_exists($releaseFilePath))
			return ;

		$release = file_get_contents($releaseFilePath);
		
		if ($release == $oldVersion)
			file_put_contents($releaseFilePath, $newVersion);
	}

	function ChangeRelease($applicationID, $version, $isRelease)
	{
		$releaseFilePath = EXPORT_APPS_PATH . "/" . $applicationID . "/" . RELEASE_FILE;
		$release = file_exists($releaseFilePath) ? file_get_contents($releaseFilePath) : "";

		if ($isRelease && $release != $version) {
			file_put_contents($releaseFilePath, $version);
			return ;
		}

		if (!$isRelease && $release == $version) {
			unlink($releaseFilePath);
			return;
		}
	}

	function RetrieveAndUnzipFile($version, $override, $isRelease)
	{
		if (!isset($_FILES) || !isset($_FILES["file"]) || !$_FILES["file"]["name"])
			return NOT_FOUND_FAILURE;

		$filename = $_FILES["file"]["name"];
		$source = $_FILES["file"]["tmp_name"];
		$applicationID = substr(basename($filename), 0, -4);

		if (!file_exists(EXPORT_APPS_PATH . "/" . $applicationID)) {
			mkdir(EXPORT_APPS_PATH . "/" . $applicationID);
		}

		if ($override !== null) {
			$status = OverrideAppVersion($applicationID, $override, $version);
			if ($status != null)
				return $status;
		}

		ChangeRelease($applicationID, $version, $isRelease);
			
		$zip = new ZipArchive;
		if (($res = $zip->open($source)) !== true)
			return UNZIP_FAILURE;

		try {

			if (!DeleteRecursiveDirectory(EXPORT_APPS_PATH . "/" . $applicationID . "/" . $version))
				return DELETE_DIRECTORY_FAILURE;

			$zip->extractTo(EXPORT_APPS_PATH . "/" . $applicationID . "/" . $version);
			$zip->close();

			unlink($source);
		} catch (Exception $e) {
			return UNZIP_FAILURE;
		}

		return SUCCESS_STATUS;
	}

	function Upload()
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;

		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["version"]) || !$_POST["version"])
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["release"]) || !$_POST["release"])
			return BAD_PARAMS_FAILURE;

		$isRelease = strtolower($_POST["release"]) == "true" ? true : false;

		$override = null;
		if (isset($_POST["override"]) && $_POST["override"])
			$override = $_POST["override"];

		return RetrieveAndUnzipFile($_POST["version"], $override, $isRelease);
	}

	echo Upload();
?>
