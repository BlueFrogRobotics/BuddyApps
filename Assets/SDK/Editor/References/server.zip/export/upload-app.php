<?php

	include 'utilities.php';

	function RetrieveAndUnzipFile($version, $override, $tags)
	{
		if (!isset($_FILES) || !isset($_FILES["file"]) || !$_FILES["file"]["name"])
			return NOT_FOUND_FAILURE;

		$filename = $_FILES["file"]["name"];
		$source = $_FILES["file"]["tmp_name"];
		$applicationID = substr(basename($filename), 0, -4);

		if (!file_exists(APPS_PATH . "/" . $applicationID))
			mkdir(APPS_PATH . "/" . $applicationID);

		if ($override !== null) {
			if (!DeleteRecursiveDirectory(APPS_PATH . "/" . $applicationID . "/" . $override))
				return DELETE_DIRECTORY_FAILURE;
		}

		SyncApplicationTags($applicationID, $tags);
			
		$zip = new ZipArchive;
		if (($res = $zip->open($source)) !== true)
			return UNZIP_FAILURE;

		try {

			if (!DeleteRecursiveDirectory(APPS_PATH . "/" . $applicationID . "/" . $version))
				return DELETE_DIRECTORY_FAILURE;

			$zip->extractTo(APPS_PATH . "/" . $applicationID . "/" . $version);
			$zip->close();

			unlink($source);
		} catch (Exception $e) {
			return UNZIP_FAILURE;
		}

		return SUCCESS_STATUS;
	}

	function Upload()
	{
		if ($_SERVER["REQUEST_METHOD"] !== "POST")
			return BAD_REQUEST_FAILURE;

		if (!isset($_POST))
			return BAD_PARAMS_FAILURE;

		if (!isset($_POST["version"]) || !$_POST["version"])
			return BAD_PARAMS_FAILURE;

		$tags = [];

		if (isset($_POST["release"]))
			$tags["release"] = $_POST["release"];

		if (isset($_POST["develop"]))
			$tags["develop"] = $_POST["develop"];

		$override = null;
		if (isset($_POST["override"]) && $_POST["override"])
			$override = $_POST["override"];

		return RetrieveAndUnzipFile($_POST["version"], $override, $tags);
	}

	echo Upload();
?>
