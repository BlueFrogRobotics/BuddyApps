﻿using UnityEngine.UI;
using UnityEngine;

using Buddy;

namespace BuddyApp.{APP_NAME}
{
    /* A basic monobehaviour as "AI" behaviour for your app */
    public class {APP_NAME}Behaviour : MonoBehaviour
    {
        /*
         * Data of the application. Save on disc when app is quitted
         */
        private {APP_NAME}Data mAppData;

        /*
         * Init refs to API and your app data
         */
        void Start()
        {
            mAppData = {APP_NAME}Data.Instance;
        }
    }
}